#!/usr/bin/env python
"""
Author    : Martin van den Akker
"""

import sys
import re
from optparse import OptionParser

## =============================================================================
##
##  Class definitions
##
## =============================================================================

## _____________________________________________________________________________
##                                                                    ObjectInfo
class ObjectInfo():
    """
    Info of an object.
    """

    def __init__(self, name="", headerWidth=60, itemWidth=30):
        """
        Initialisation
        """
        self._name = name

        self._headerWidth = headerWidth
        self._itemWidth = itemWidth
        self._indent = 2


    def summaryItem(self, name="[item]", width=None, indent=0):
        """
        Item of the object summary.
        """
        result = ""

        dot_char = "."

        if width is None:
            width = self._itemWidth

        result += " "*(self._indent + indent)
        result += name
        result += dot_char*max(0,width-(len(name)+self._indent+indent))
        result += " : "

        return result


    def summaryLine(self,width=None, linechar="="):
        """
        Horizontal line
        """
        if width is None:
            width = self._headerWidth

        print linechar*width


    def summaryHeader(self, width=None):
        """
        Header of the object summary.
        """
        if width is None:
            width = self._headerWidth

        self.summaryLine(width)
        print "  Summary of %s object" %(self._name)
        self.summaryLine(width)


# ______________________________________________________________________________
#                                                                       RefError
class RefError():
    """
    Reference error
    """

    def __init__(self, filename="", line=0):
        """
        Initialisation
        """
        info = ObjectInfo("RefError")

        self._filename = filename
        self._line = line


    def get_filename(self):
        return self._filename


    def set_filename(self, value):
        self._filename = value


    filename = property(get_filename, set_filename)

    def summary(self):
        """
        Summary of the RefError object.
        """
        info.summaryHeader()

        print info.summaryItem("Filename") + self._filename
        print info.summaryItem("Line") + str(self._line)

        info.summaryLine()


# ______________________________________________________________________________
#                                                                      CiteError
class CiteError():
    """
    Citation Error
    """

    def __init__(self, filename="", line=0):
        """
        Initialisation
        """
        info  = ObjectInfo("CiteError")

        self._filename = ""
        self._line = 0


    def summary(self):
        """
        Summary of the CiteError object.
        """
        info.summaryHeader()

        print info.summaryItem("Filename") + self._filename
        print info.summaryItem("Line") + str(self._line)

        info.summaryLine()


# ______________________________________________________________________________
#                                                                   AcronymError
class AcronymError():
    """
    Acronym Error
    """

    def __init__(self, filename="", line=0):
        """
        Initialisation
        """
        info  = ObjectInfo("AcronymError")

        self._filename = ""
        self._line = 0


    def summary(self):
        """
        Summary of the AcronymError object.
        """
        info.summaryHeader()

        print info.summaryItem("Filename") + self._filename
        print info.summaryItem("Line") + str(self._line)

        info.summaryLine()


## _____________________________________________________________________________
##                                                                       LogFile
class LogFile():
    """
    LaTeX log file.
    """

    def __init__(self, filename="", options=None):
        """
        Initialisation of log file.

        *filename* Filename of the log file.
        """
        self._file = None
        self._filename = filename
        self._lines = []
        self._refErrors = []
        self._citeErrors = []
        self._acronymErrors = []
        self._isChecked = False
        self._options = options

        self.info = ObjectInfo("LogFile")


    def isOpen(self):
        """
        Check the file status.
        """
        if (self._file is None):
            return False
        else:
            return True


    def open(self, filename=""):
        """
        Open the logfile

        *filename* Filename of the log file.
        """
        if (self._options.verbose):
            print "Opening log-file..."

        if (filename != ""):
            self._filename = filename

        if (self._filename != "" and not self.isOpen()):
            self._file = open(self._filename, 'r')


    def read(self):
        """
        Read the content of the logfile.
        """
        if (self._options.verbose):
            print "Reading log-file..."

        for line in self._file:
            self._lines.append(line)


    def close(self):
        """
        Close the log file.
        """
        if (self._options.verbose):
            print "Closing log-file..."

        if (self._file != None):
            self._file.close()

        self._file = None


    def check(self):
        """
        Check for errors in the log file.
        """
        if (self._options.verbose):
            print "Checking log-file..."

        if (len(self._lines) > 0):
            self.checkReferences()
            self.checkCitations()
            self.checkAcronyms()
            nErrors = len(self._refErrors) + len(self._citeErrors) + len(self._acronymErrors)
            if (nErrors > 0):
                exit(1)
            else:
                print "OK: No errors found."
        else:
            raise ValueError("Error: No lines read in.")

        self._isChecked = True


    def checkCitations(self):
        """
        Check for citation errors.
        """

        if (self._options.verbose):
            print "  Checking for citation errors..."

        if (len(self._lines) > 0):
            for line_idx in range(len(self._lines)):
                line  = self._lines[line_idx].strip()
                match = re.match(".* Warning: Citation", line)
                # Check for trigger
                if (match is not None):
                    # Read complete line
                    line_idx2 = line_idx
                    longline = ""
                    while (len(self._lines[line_idx2]) > 1):
                        longline += self._lines[line_idx2].strip()
                        line_idx2 += 1
                        if (line_idx2 >= len(self._lines)):
                            break

                    # Find errorfilename
                    errorfilename = ""
                    line_idx2 = line_idx
                    while ((len(errorfilename)==0) & (line_idx2>0)):
                        match = re.match("^.*\((.*\.tex)$", self._lines[line_idx2])
                        if (match is not None):
                            errorfilename = match.group(1)
                        line_idx2 -= 1

                    # Extract parameters
                    match = re.match(".*Warning: Citation `(.*)'.*line[ ]*([0-9]*).", longline)
                    if (match is not None):
                        refid = match.group(1)
                        linenr = int(match.group(2))

                        citeError = CiteError(errorfilename, linenr)
                        self._citeErrors.append(citeError)
                        print "%s:%d:  Citation error for label %s" %(errorfilename, linenr, refid)


    def checkReferences(self):
        """
        Check for reference errors.
        """

        if (self._options.verbose):
            print "  Checking for reference errors..."

        if (len(self._lines) > 0):
            for line_idx in range(len(self._lines)):
                line = self._lines[line_idx].strip()
                match = re.match(".*LaTeX Warning: Reference", line)
                # Check for trigger
                if (match is not None):
                    # Read complete line (i.e. remove linebreaks)
                    line_idx2 = line_idx
                    longline = ""
                    while (len(self._lines[line_idx2]) > 1):
                        longline += self._lines[line_idx2].strip()
                        line_idx2 += 1
                        if (line_idx2 >= len(self._lines)):
                            break

                    # Find errorfilename
                    errorfilename = ""
                    line_idx2 = line_idx
                    while ((len(errorfilename)==0) & (line_idx2>0)):
                        match = re.match("^.*\((.*\.tex)$", self._lines[line_idx2])
                        if (match is not None):
                            errorfilename = match.group(1)
                        line_idx2 -= 1

                    # Extract parameters
                    match = re.match(".*LaTeX Warning: Reference `(.*)'.*line[ ]*([0-9]*).", longline)
                    if (match is not None):
                        refid = match.group(1)
                        linenr = int(match.group(2))

                        refError = RefError(errorfilename, linenr)
                        self._refErrors.append(refError)
                        print "%s:%d:  Reference error for label %s" %(errorfilename, linenr, refid)


    def checkAcronyms(self):
        """
        Check for acronym errors

        Error messages look like:
        Package acronym Warning: Acronym `CORSICA' is not defined on input line 182.
        """
        if (self._options.verbose):
            print "  Checking for acronym errors..."

        if (len(self._lines) > 0):
            for line_idx in range(len(self._lines)):
                line = self._lines[line_idx].strip()
                match = re.match(".*Package acronym Warning: Acronym", line)
                # Check for trigger
                if (match is not None):
                    # Read complete line (i.e. remove linebreaks)
                    line_idx2 = line_idx
                    longline = ""
                    while (len(self._lines[line_idx2]) > 1):
                        longline += self._lines[line_idx2].strip()
                        line_idx2 += 1
                        if (line_idx2 >= len(self._lines)):
                            break

                    # Find errorfilename
                    errorfilename = ""
                    line_idx2 = line_idx
                    while ((len(errorfilename)==0) & (line_idx2>0)):
                        match = re.match(".*^\((.*\.tex)$", self._lines[line_idx2])
                        if (match is not None):
                            errorfilename = match.group(1)
                        line_idx2 -= 1

                    # Extract parameters
                    match = re.match(".*Package acronym Warning: Acronym `(.*)'.*line[ ]*([0-9]*).", longline)
                    if (match is not None):
                        refid = match.group(1)
                        linenr = int(match.group(2))

                        acronymError = AcronymError(errorfilename, linenr)
                        self._acronymErrors.append(acronymError)
                        print "%s:%d:  Acronym error for label %s" %(errorfilename, linenr, refid)


    def summary(self):
        """
        Summary of the LogFile object
        """
        self.info.summaryHeader()

        print "  File:"
        print self.info.summaryItem("Name", indent=2) + self._filename
        if self.isOpen():
            status = "Open"
        else:
            status = "Closed"
        print self.info.summaryItem("Status", indent=2) + status
        print self.info.summaryItem("Lines", indent=2) + str(len(self._lines))
        print self.info.summaryItem("Checked", indent=2) + str(self._isChecked)
        # print "  Errors: "
        # print self.info.summaryItem("References", indent=2) + str(len(self._refErrors))
        # print self.info.summaryItem("Citations", indent=2) + str(len(self._citeErrors))

        self.info.summaryLine()


## =============================================================================
##
##  Function definitions
##
## =============================================================================

## _____________________________________________________________________________
##                                                                 Option parser

def optionParser():
    """
    Parser for command line options.
    """

    usage_string = "usage: %prog [options] logfile"
    parser = OptionParser(usage_string)

    # Verbose option
    parser.add_option("-v", "--verbose",
                      action="store_true", dest="verbose", default=True,
                      help="show verbose processing information [default]")

    # Quiet option
    parser.add_option("-q", "--quiet",
                      action="store_false", dest="verbose",
                      help="hide processing information")

    (options, args) = parser.parse_args()

    if (len(args) != 1):
        parser.error("Incorrect number of arguments")

    return (options, args)


## =============================================================================
##
##  Main
##
## =============================================================================

def main():
    """
    Main routine
    """
    (options, args) = optionParser()

    logfile = LogFile(args[0], options)

    logfile.open()
    logfile.read()
    logfile.check()
    logfile.close()

    if (options.verbose):
        logfile.summary()


if __name__ == '__main__':
    main()
